package com.epam.test.automation.java.practice4;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        System.out.println("SortOrder.ASC {10, 5, 14, 4} "+Task1.isSorted(new int [] {10, 5, 14, 4}, SortOrder.ASC));
        System.out.println("SortOrder.ASC {1, 2, 3, 4} "+Task1.isSorted(new int [] {1, 2, 3, 4}, SortOrder.ASC));
        System.out.println("SortOrder.DESC {11, 18, 3, 5} "+Task1.isSorted(new int [] {11, 18, 3, 5}, SortOrder.DESC));
        System.out.println("SortOrder.DESC {11, 10, 9, 8} "+Task1.isSorted(new int [] {11, 10, 9, 8}, SortOrder.DESC));
        System.out.println("SortOrder.DESC {11, 11, 11, 11} "+Task1.isSorted(new int [] {11, 11, 11, 11}, SortOrder.DESC));

        System.out.println("SortOrder.ASC {5, 17, 24, 88, 33, 2} "+Arrays.toString(Task2.transform(new int [] {5, 17, 24, 88, 33, 2}, SortOrder.ASC)));
        System.out.println("SortOrder.ASC {15, 10, 3} "+Arrays.toString(Task2.transform(new int [] {15, 10, 3}, SortOrder.ASC)));
        System.out.println("SortOrder.ASC {5, 17, 24, 88, 33, 2} "+Arrays.toString(Task2.transform(new int [] {5, 17, 24, 88, 33, 2}, SortOrder.ASC)));
        System.out.println("SortOrder.DESC {15, 10, 3} "+ Arrays.toString(Task2.transform(new int [] {15, 10, 3},SortOrder.DESC)));
   //     System.out.println("SortOrder.DESC {15, 10, 3} "+ Arrays.toString(Task2.transform(new int [] {},SortOrder.DESC)));

        System.out.println(Task3.multiArithmeticElements(5,3,4));

     //  System.out.println(Task4.sumGeometricElements(100,0.5,20));
        System.out.println(Task4.sumGeometricElements(100,0.9,50));
//        System.out.println(Task4.sumGeometricElements(0,0,0));
    }
}