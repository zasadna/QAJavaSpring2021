package com.epam.test.automation.java.practice4;

public enum SortOrder {
    ASC,
    DESC;
}
